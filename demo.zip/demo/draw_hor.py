import glob
import os.path
from PIL import Image, ImageDraw
import math
import numpy as np
import heapq
import pandas as pd
import time
import math
from scipy.spatial import distance
import cv2
import matplotlib.pyplot as plt
import math
import os
import string
import sys
from math import *


imgpath = '/Users/joy/project/final/deck/perspect/500/' #要處理的影像

hfpath = "/Users/joy/project/final/predict_result/hor_result.txt"   # deck  預測結果檔
hpath = "/Users/joy/project/final/hor/pd/"  #  deck  存預測匡的文件檔路徑#取得水平預測匡

hf = open(hfpath, 'r')
name=""
# 初始化輸出文件的文件指標和數據字符串
fTxt = None
s = ""

# 遍歷讀取每一行
for line in hf.readlines():
    yolo_datas = line.split()
    
    # 檢查行是否包含 'Predicted'
    if 'Predicted' in line:
        # 如果s中有數據且fTxt已初始化，將其寫入文件並關閉文件
        if s != "" and fTxt is not None:
            fTxt.write(s)
            fTxt.close()
            s = ""  # 重置字符串以準備下一組坐標
        
        # 提取文件名
        name = (line.split("/"))[8].split(".")
        
        # 打開新的文件以寫入提取的文件名
        fTxt = open(hpath + name[0] + ".txt", 'w')
    
    # 檢查行是否包含坐標數據
    if '(left_x:' in yolo_datas:
        index = yolo_datas.index('(left_x:')
        
        # 從行中提取坐標
        left_x = yolo_datas[index + 1]
        top_y = yolo_datas[index + 3]
        width = yolo_datas[index + 5]
        height = yolo_datas[index + 7].split(')')[0]
        
        # 將提取的坐標附加到字符串s
        s += left_x + " " + top_y + " " + width + " " + height + "\n"

# 將s中剩餘的數據寫入最後一個文件並關閉它（如果fTxt已初始化）
if fTxt is not None:
    fTxt.write(s)
    fTxt.close()
    
# 關閉輸入文件
hf.close()



# Function to draw bounding boxes on an image and save it
def draw_boxes_and_save(image_path, box_coordinates, output_dir):
    # Open the image
    img = Image.open(image_path)
    draw = ImageDraw.Draw(img)
    pink_color = (255, 192, 203)
    # Draw bounding boxes
    for box in box_coordinates:
        left_x, top_y, width, height = map(int, box)
        draw.rectangle([left_x, top_y, left_x + width, top_y + height], outline="pink", width=15)
    
    # Save the image with bounding boxes
    image_name = os.path.basename(image_path)
    output_path = os.path.join(output_dir, image_name)
    img.save(output_path)

# Directory where images with bounding boxes will be saved
output_dir = '/Users/joy/project/final/hor/draw_pd/'

# Iterate through all the text files containing bounding box coordinates
for txt_file in glob.glob(hpath + "*.txt"):
    # Read bounding box coordinates from the text file
    with open(txt_file, 'r') as f:
        box_coordinates = [list(map(float, line.split())) for line in f]
    
    # Extract image name from the text file name
    image_name = os.path.basename(txt_file).split('.')[0] + '.jpg'
    image_path = os.path.join(imgpath, image_name)
    
    # Draw bounding boxes on the image and save it
    draw_boxes_and_save(image_path, box_coordinates, output_dir)
