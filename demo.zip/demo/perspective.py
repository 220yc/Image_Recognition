'''
needing file
1,要做的影像 ./final/predict_img/

2.預測結果 ./final/predict_result/
-- ./final/predict_result/guardrail_result.txt
-- ./final/predict_result/deck_result.txt

3.畫線
imgSPath = "./final/deck/pre_line/"
imgS2Path = imgSPath+"90_5/" #存畫出的線

4.擬合 
intePath = "./final/deck/pre_line/integrate/"   ##擬合的結果路徑

5.透視
sPath = "./final/deck/perspect"+str(dis_t)+"/"

6.demo
output_folder = "./final/demo/"

verGTPath = "/Users/joy/project/GroundTrue/"
horImgPath = "/Users/joy/project/hor_HE/data_from_zeng/"
horGTPath = "/Users/joy/project/hor_HE/data_from_zeng/"

'''
import glob
import os.path
from PIL import Image, ImageDraw
import math
import numpy as np
import heapq
import pandas as pd
import time
import math
from scipy.spatial import distance
import cv2
import matplotlib.pyplot as plt
import math
import os
import string
import sys
from math import *


imgpath = '/Users/joy/project/final/preprocess/' #要處理的影像

########
#1 取匡
vfpath = "/Users/joy/project/final/predict_result/vec_result.txt"  # 垂直  預測結果檔
vpath = "/Users/joy/project/final/vec/pd/" #      垂直 存預測匡的文件檔路徑

dfpath = "/Users/joy/project/final/predict_result/deck_result.txt"   # deck  預測結果檔
dpath = "/Users/joy/project/final/deck/pd/"  #  deck  存預測匡的文件檔路徑
######################
#2. 畫線
imgSPath = "/Users/joy/project/final/deck/pre_line/"
imgS2Path = imgSPath+"90_5/" #存畫出的線

#3. 擬合
linePath = "/Users/joy/project/final/deck/pre_line/90_5/"  ##在第二部畫出的線的座標
intePath = "/Users/joy/project/final/deck/integrate/"   ##擬合的結果路徑

#4. 透視
#Jpath = "/Users/joy/project/IMG/" ##要透視的影像
#intePath = "/Users/joy/project/deck_HE/pre_line/integrate/"  ##擬合的線段
#vpath = "/Users/joy/project/vec_HE/GT_predict/"  ##垂直護欄預測匡
# sPath = "/Users/joy/project/deck_HE/pre_line/perspective/"

dis_t = 500
sPath = "/Users/joy/project/final/deck/perspect/"+str(dis_t)+"/"

#2.畫線
####deck畫線
def least_squares(y, x_mat):
    a = x_mat.T.dot(x_mat)
    b = x_mat.T.dot(y)
    reg_const = 1e-6  # Adjust the value as needed
    a += reg_const * np.eye(a.shape[0])
    #print(a)
    return np.linalg.solve(a, b)

def getNewDist(p1, p2):
    p = [p1, p2]
#     print(p)
    p.sort(key=lambda p:p[1])
#     print(p)

    X=[]
    Y=[]
    X.append(p[0][1]+p[0][3]/2)
    Y.append(p[0][2]+p[0][4]/2)
    X.append(p[1][1]+p[1][3]/2)
    Y.append(p[1][2]+p[1][4]/2)
#     print("X:", X)
#     print("Y:", Y)
#     print("index", X.index(min(X)))
    minIdx = X.index(min(X))
    maxIdx = X.index(max(X))
    n = len(Y)
    x_mat = np.c_[np.ones(n), X]
    w = least_squares(Y, x_mat)
#     print("w:", w)
    #Y = w[0]+w[1]*X
    n = 0  #距離
    n_1 = 0#在BOX1內的點
    n_2 = 0#在BOX2內的點
    n_3 = 0#重疊距離

    Dw = abs(X[maxIdx]-X[minIdx])
    Dh = abs(Y[Y.index(max(Y))]-Y[Y.index(min(Y))])
    
#     print("Dw v.s. Dh: %.1f v.s. %.1f" %(Dw, Dh))

    if Dw>=Dh:
        for i in range(round(X[minIdx]), round(X[maxIdx]+1)):
    #         print(i)
            tmpY = w[0]+w[1]*i
            if Y[0] == Y[1]:
                if i<p[minIdx][1]+p[minIdx][3]:
                    n_1 += 1
                elif i>p[maxIdx][1]:
                    n_2 += 1
                else:
                    n += 1
            elif minIdx == Y.index(min(Y)):
                if tmpY<p[minIdx][2]+p[minIdx][4] and i<p[minIdx][1]+p[minIdx][3]:
        #             print(tmpY, "<", p[minIdx][2]+p[minIdx][4])
                    n_1 += 1
                elif tmpY>p[maxIdx][2] and i>p[maxIdx][1]:
        #             print(tmpY, ">", p[maxIdx][2])
                    n_2 += 1
                else:
                    n += 1
        #         print("==================")
            else:
                if tmpY>p[minIdx][2] and i<p[minIdx][1]+p[minIdx][3]:
        #             print(tmpY, "<", p[minIdx][2]+p[minIdx][4])
                    n_1 += 1
                elif tmpY<p[maxIdx][2]+p[maxIdx][4] and i>p[maxIdx][1]:
        #             print(tmpY, ">", p[maxIdx][2])
                    n_2 += 1
                else:
                    n += 1
        #         print("==================")

#         print(X[maxIdx]-X[minIdx]+1)
#         print("n1 =", n_1)
        if n==0:
            for i in range(round(X[minIdx]), round(X[maxIdx]+1)):
                tmpY = w[0]+w[1]*i
                if Y[0] == Y[1]:
                    if i<p[minIdx][1]+p[minIdx][3] and i>p[maxIdx][1]:
                        n_3 -= 1
                elif minIdx == Y.index(min(Y)):
                    if tmpY<p[minIdx][2]+p[minIdx][4] and i<p[minIdx][1]+p[minIdx][3] and tmpY>p[maxIdx][2] and i>p[maxIdx][1]:
                        n_3 -= 1
                else:
                    if tmpY>p[minIdx][2] and i<p[minIdx][1]+p[minIdx][3] and tmpY<p[maxIdx][2]+p[maxIdx][4] and i>p[maxIdx][1]:
                        n_3 -= 1

        #     n = -(getDist(X[minIdx], w[0]+w[1]*X[minIdx], X[maxIdx], w[0]+w[1]*X[maxIdx]))
#             print("n_3 =", n_3)
            return n_3
        else:
#             print("n =", n)
            return n
#         print("n2 =", n_2)
    else:
#         print("Dw<Dh")   
        minIdx = Y.index(min(Y))
        maxIdx = Y.index(max(Y))
        for i in range(round(Y[minIdx]), round(Y[maxIdx]+1)):
    #         print("Y:", i)
            tmpX = (i-w[0])/w[1]
#             print(tmpX)
    #         print("min:", p[minIdx][1]+p[minIdx][3], "max:", p[maxIdx][1])
#             print("minIdx v.s maxIdx:", minIdx, maxIdx)
            if X[0]==X[1]:
                if i<p[minIdx][2]+p[minIdx][4]:
                    n_1 += 1
                elif i>p[maxIdx][2]:
                    n_2 +=2
                else:
                    n +=1                
                #print(w)
            elif minIdx == X.index(min(X)):
                if tmpX<p[minIdx][1]+p[minIdx][3] and i<p[minIdx][2]+p[minIdx][4]:
                    n_1 += 1
                elif tmpX>p[maxIdx][1] and i>p[maxIdx][2]:
                    n_2 += 1
                else:
                    n += 1
        #         print("================")
            else:
                if tmpX>p[minIdx][1] and i<p[minIdx][2]+p[minIdx][4]:
                    n_1 += 1
                elif tmpX<p[maxIdx][1]+p[maxIdx][3] and i>p[maxIdx][2]:
                    n_2 += 1
                else:
                    n += 1

#         print(Y[maxIdx]-Y[minIdx]+1)        
#         print("n1 =", n_1)
        if n==0:
            for i in range(round(Y[minIdx]), round(Y[maxIdx]+1)):
                tmpX = (i-w[0])/w[1]
                if X[0]==X[1]:
                    if i>p[maxIdx][2] and i<p[minIdx][2]+p[minIdx][4]:
                        n_3 -= 1
                elif minIdx == X.index(min(X)):
                    if tmpX<p[minIdx][1]+p[minIdx][3] and i<p[minIdx][2]+p[minIdx][4] and tmpX>p[maxIdx][1] and i>p[maxIdx][2]:
                        n_3 -= 1
                else:
                    if tmpX>p[minIdx][1] and i<p[minIdx][2]+p[minIdx][4] and tmpX<p[maxIdx][1]+p[maxIdx][3] and i>p[maxIdx][2]:
                        n_3 -= 1

        #     n = -(getDist(X[minIdx], w[0]+w[1]*X[minIdx], X[maxIdx], w[0]+w[1]*X[maxIdx]))
#             print("n_3 =", n_3)
            return n_3
        else:
#             print("n =", n)
            return n
#         print("n2 =", n_2)

        
##3.deck線段擬合
def calAngle(line):
    x1, y1, x2, y2 = line
    if x1 > x2:
        tmp = x1
        tmp2 = y1
        x1 = x2
        y1 = y2
        x2 = tmp
        y2 = tmp2
    sT1= x2-x1
    if sT1==0:
        sT1 = 0.001
        #print("in")
    slope1 = (y2-y1)/sT1
    a1 = math.degrees(math.atan(slope1))
#     print(a1)
    return round(a1)

def least_squares(y, x_mat):
    a = x_mat.T.dot(x_mat)
    b = x_mat.T.dot(y)
    return np.linalg.solve(a, b)


##4.透視
def eucliDist(A,B):
    return int(math.sqrt(sum([(a - b)**2 for (a,b) in zip(A,B)])))

def point_line_dis(p, lp1, lp2):
    vec1 = lp1 - p
    vec2 = lp2 - p
    dis = np.abs(np.cross(vec1, vec2))/np.linalg.norm(lp1-lp2)
    return dis

# imgpath = "/Users/joy/project/IMG/" ##要透視的影像
# intePath = "/Users/joy/project/deck_HE/pre_line/integrate/"  ##擬合的線段
# vpath = "/Users/joy/project/vec_HE/GT_predict/"  ##垂直護欄預測匡
# # sPath = "/Users/joy/project/deck_HE/pre_line/perspective/"

# dis_t = 500
# sPath = "/Users/joy/project/deck_HE/pre_line/claheIMG_perspective_t_"+str(dis_t)+"/"

for jpgpath in glob.glob(intePath + '*.jpg'):
   #print(jpgpath)
    completejpgname=os.path.basename(jpgpath)
#     print("File-Name_with_extension：",completejpgname) #取得檔案完整名稱
    jpgname=completejpgname.split(".jpg")
    #print("File-Name：",jpgname[0])      #取得檔案名
    img = Image.open(imgpath+completejpgname) 
    img1 = cv2.imread(imgpath+completejpgname)
#     img1 = ImageDraw.Draw(img)  
    width, height = img.size
    #print("width:", width, "height:", height)
    _GR = []
    GRF = open(vpath+jpgname[0]+".txt", 'r') #GuardRail
    for line in GRF.readlines():
        line = line.strip("\n")
#         line = line.strip("[")
#         line = line.strip("]")
#         line = line.strip(" ")
        line = line.split(" ")
        GR = [float(l) for l in line]
        _GR.append(GR)
        #print("GuardRail:", GR)
    GRF.close()
    #print("===========")
    DF = open(intePath+jpgname[0]+".txt", 'r') #Deck
    dn = 0
    for line in DF.readlines():
        line = line.strip("\n")
        line = line.strip("[")
        line = line.strip("]")
        line = line.strip(" ")
        line = line.split(",")
#         print(line)
        D = [round(float(l), 1) for l in line]
        #print("Deck_Line:", D, "\n#############")
        D_x1 = D[0]
        D_y1 = D[1]
        D_x2 = D[2]
        D_y2 = D[3]
        if D_x1 > D_x2:
            D_x1 = D[2]
            D_y1 = D[3]
            D_x2 = D[0]
            D_y2 = D[1]
        if (eucliDist((D_x1,D_y1), (D_x2,D_y2))) <300:
            continue
        deck_angle = calAngle(D) 
        #print("deck_angle:", deck_angle)
        out_min_x = 100000
        out_min_dis = 100000 #左邊外面最近，距離最近
        out_min_idx = -1
        in_min_x = 100000
        in_min_dis = 100000 #左邊裡面最近，距離最近
        in_min_idx = -1
        out_max_x = 0
        out_max_dis = 100000 #右邊外面最近，距離最近
        out_max_idx = -1
        in_max_x = 0
        in_max_dis = 100000 #右邊裡面最近，距離最近
        in_max_idx = -1
        left_GR = []
        right_GR = []
        left_GR_Idx = -1
        right_GR_Idx = -1
        for gr in range(len(_GR)): #lt=>leftTop, bc=>bottomCenter
#             print(gr)
            lt_x, lt_y, w, h = _GR[gr]
#             lt_x = gr[0]
#             lt_y = gr[1]
#             w = gr[2]
#             h = gr[3]
            bc_x = lt_x+w/2
            bc_y = lt_y+h
#             if bc_x>D_x1 and bc_x<D_x2:
#                 bc_x_dis = point_line_dis(np.array([bc_x,bc_y]), np.array([D_x1,D_y1]), np.array([D_x2,D_y2]))
#             else:
            bc_x_dis1 = eucliDist((bc_x,bc_y),(D_x1,D_y1))
            bc_x_dis2 = eucliDist((bc_x,bc_y),(D_x2,D_y2))
            bc_x_dis = min(bc_x_dis1, bc_x_dis2)
            #print("ANGLE_P_DECK:", )
            #print("1, 2:",bc_x_dis1, bc_x_dis2)
            #print(gr, "DIS:", bc_x_dis)
            if bc_x<D_x1 and bc_x_dis<out_min_dis: #"找外部左邊最近"
                if bc_x_dis>dis_t:
                    continue
                out_min_x = bc_x
                out_min_y = bc_y
                out_min_dis = bc_x_dis
                out_min_idx = gr
            if bc_x>D_x2 and bc_x_dis<out_max_dis: #"找外部右邊最近"
                if bc_x_dis>dis_t:
                    continue
                out_max_x = bc_x
                out_max_y = bc_y
                out_max_dis = bc_x_dis
                out_max_idx = gr
            if bc_x>D_x1 and bc_x<D_x2 and bc_x_dis1<in_min_dis: #"找內部左邊最近"
                if bc_x_dis1>dis_t:
                    continue
                in_min_x = bc_x
                in_min_y = bc_y
                in_min_dis = bc_x_dis1
                in_min_idx = gr
            if bc_x>D_x1 and bc_x<D_x2 and bc_x_dis2<in_max_dis: #"找內部右邊最近"
                if bc_x_dis2>dis_t:
                    continue
                in_max_x = bc_x
                in_max_y = bc_y
                in_max_dis = bc_x_dis2
                in_max_idx = gr
            #print(out_min_dis, out_max_dis, in_min_dis, in_max_dis)
            #print(out_min_x, out_max_x, in_min_x, in_max_x)
        if out_min_x != 100000:
            left_GR = [out_min_x, out_min_y]
            left_GR_Idx = out_min_idx
        elif in_min_x != 100000:
            left_GR = [in_min_x, in_min_y]
            left_GR_Idx = in_min_idx
        if out_max_x != 0:
            right_GR = [out_max_x, out_max_y]
            right_GR_Idx = out_max_idx
        elif in_max_x != 0:
            right_GR = [in_max_x, in_max_y]
            right_GR_Idx = in_max_idx

        #print("left and right:", left_GR, right_GR)
        #print("left and right2:",left_GR_Idx, right_GR_Idx)
        if left_GR_Idx==-1 or right_GR_Idx==-1 or left_GR_Idx==right_GR_Idx: #單個欄杆或沒有欄杆的影像
            if left_GR_Idx!=-1: #已經有左邊欄杆
                p_lb_x = _GR[left_GR_Idx][0]
                p_lt_y = _GR[left_GR_Idx][1]
                p_lb_y = _GR[left_GR_Idx][1]+_GR[left_GR_Idx][3]
                p_rt_y = _GR[left_GR_Idx][1] #virtual GR TOP_Y
                p_rb_x = D_x2 #virtual GR X
                p_rb_y = D_y2#virtual GR bottom_Y(p_rb_x代入deck線段)
                if D_y2<p_lt_y:
                    continue
                dis_lb_rb= p_rb_x-p_lb_x
                vir_h = p_lb_y - p_rt_y
                vec_h = _GR[left_GR_Idx][3]
                max_ver_GR = max(vir_h, vec_h)
                pts1 = np.float32([[p_lb_x, p_lt_y-50],[p_rb_x, p_rt_y-50],[p_lb_x, p_lb_y+50],[p_rb_x, p_rb_y+50]]) #被透視四個座標
                pts2 = np.float32([[0, 0], [dis_lb_rb, 0], [0, max_ver_GR+100], [dis_lb_rb, max_ver_GR+100]]) #透視後四個座標
                #print("pts1", pts1)
                #print("pts2", pts2)
                M = cv2.getPerspectiveTransform(pts1,pts2)
                crop_w = round(dis_lb_rb)
                crop_h = round(max_ver_GR)
                #print("crop:", (crop_w,crop_h))
                res = cv2.warpPerspective(img1,M,(crop_w,crop_h))
                #print("RES2:", res.size)
                cv2.imwrite(sPath+jpgname[0]+"_"+str(dn)+".jpg", res)
                #print(sPath+jpgname[0]+"_"+str(dn)+".jpg")
                dn = dn+1
                continue
            if right_GR_Idx!=-1:
                #print(type(right_GR_Idx))
                p_rb_x = _GR[right_GR_Idx][0]
                p_rt_y = _GR[right_GR_Idx][1]
                p_rb_y = _GR[right_GR_Idx][1]+_GR[right_GR_Idx][3]
                p_lb_x = D_x1
                p_lt_y = p_rt_y
                p_lb_y = D_y1
                if p_lb_y<p_rt_y:
                    continue
                vir_h = p_lb_y-p_lt_y
                vec_h = _GR[right_GR_Idx][3]
                max_ver_GR = max(vir_h, vec_h)
                dis_lb_rb = p_rb_x - p_lb_x
                pts1 = np.float32([[p_lb_x, p_lt_y-50],[p_rb_x, p_rt_y-50],[p_lb_x, p_lb_y+50],[p_rb_x, p_rb_y+50]]) #被透視四個座標
                pts2 = np.float32([[0, 0], [dis_lb_rb, 0], [0, max_ver_GR+100], [dis_lb_rb, max_ver_GR+100]]) #透視後四個座標
                #print("pts1", pts1)
                #print("pts2", pts2)
                M = cv2.getPerspectiveTransform(pts1,pts2)
                crop_w = round(dis_lb_rb)
                crop_h = round(max_ver_GR)
                #print("crop:", (crop_w,crop_h))
                res = cv2.warpPerspective(img1,M,(crop_w,crop_h))
                #print("RES2:", res.size)
                cv2.imwrite(sPath+jpgname[0]+"_"+str(dn)+".jpg", res)
                #print(sPath+jpgname[0]+"_"+str(dn)+".jpg")
                dn = dn+1               
                continue
            continue
        max_ver_GR = max(_GR[left_GR_Idx][3], _GR[right_GR_Idx][3])
        #print("cut_h:", max_ver_GR)
        p_lb_x = _GR[left_GR_Idx][0]
        p_rb_x = _GR[right_GR_Idx][0]+_GR[right_GR_Idx][2]
        dis_lb_rb = p_rb_x-p_lb_x
        #print("cut_w:", dis_lb_rb)
        bottom_y = max(_GR[left_GR_Idx][1]+_GR[left_GR_Idx][3], _GR[right_GR_Idx][1]+_GR[right_GR_Idx][3])
        top_y = min(_GR[left_GR_Idx][1], _GR[right_GR_Idx][1])
        img2 = img1.copy()
        #print(int(top_y),int(bottom_y), int(p_lb_x),int(p_rb_x))
        if top_y < 0:
            top_y = 0
        if p_lb_x < 0:
            p_lb_x = 0
        img2 = img2[int(top_y):int(bottom_y), int(p_lb_x):int(p_rb_x)] #[左上Y:右下Y,左上X:右下X]
        #print("img2", img2.size)
#         if abs(deck_angle)<5:
#             cv2.imwrite(sPath+jpgname[0]+"_"+str(dn)+".jpg", img2)
#             print(sPath+jpgname[0]+"_"+str(dn)+".jpg")
#         else:
        #print("1:", [[p_lb_x, _GR[left_GR_Idx][1]],[p_rb_x, _GR[right_GR_Idx][1]],[p_lb_x, _GR[left_GR_Idx][1]+_GR[left_GR_Idx][3]],[p_rb_x, _GR[right_GR_Idx][1]+_GR[right_GR_Idx][3]]])
        pts1 = np.float32([[p_lb_x, _GR[left_GR_Idx][1]],[p_rb_x, _GR[right_GR_Idx][1]],[p_lb_x, _GR[left_GR_Idx][1]+_GR[left_GR_Idx][3]],[p_rb_x, _GR[right_GR_Idx][1]+_GR[right_GR_Idx][3]]]) #被透視四個座標
        pts2 = np.float32([[0, 0], [dis_lb_rb, 0], [0, max_ver_GR], [dis_lb_rb, max_ver_GR]]) #透視後四個座標
        #print("pts1", pts1)
        #print("pts2", pts2)
        M = cv2.getPerspectiveTransform(pts1,pts2)
        #print("RES:", (dis_lb_rb,max_ver_GR))
        crop_w = round(dis_lb_rb)
        crop_h = round(max_ver_GR)
        #print("crop:", (crop_w,crop_h))
        res = cv2.warpPerspective(img1,M,(crop_w,crop_h))
        #print("RES2:", res.size)
        cv2.imwrite(sPath+jpgname[0]+"_"+str(dn)+".jpg", res)
        #print(sPath+jpgname[0]+"_"+str(dn)+".jpg")
#             cv2.imwrite(sPath+jpgname[0]+"_"+str(dn)+".jpg", img2)
                    
        dn = dn+1
        #print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
#     if dn == 0:
#         cv2.imwrite(sPath+jpgname[0]+"_dn0"+".jpg", img2)
    DF.close()
    #print("=====read end======")
#     break