'''
needing file
1,要做的影像 ./final/predict_img/

2.預測結果 ./final/predict_result/
-- ./final/predict_result/guardrail_result.txt
-- ./final/predict_result/deck_result.txt

3.畫線
imgSPath = "./final/deck/pre_line/"
imgS2Path = imgSPath+"90_5/" #存畫出的線

4.擬合 
intePath = "./final/deck/pre_line/integrate/"   ##擬合的結果路徑

5.透視
sPath = "./final/deck/perspect"+str(dis_t)+"/"

6.demo
output_folder = "./final/demo/"

verGTPath = "/Users/joy/project/GroundTrue/"
horImgPath = "/Users/joy/project/hor_HE/data_from_zeng/"
horGTPath = "/Users/joy/project/hor_HE/data_from_zeng/"

'''
import glob
import os.path
from PIL import Image, ImageDraw
import math
import numpy as np
import heapq
import pandas as pd
import time
import math
from scipy.spatial import distance
import cv2
import matplotlib.pyplot as plt
import math
import os
import string
import sys
from math import *


imgpath = '/Users/joy/project/final/preprocess/' #要處理的影像
#1 取匡
vfpath = "/Users/joy/project/final/predict_result/vec_result.txt"  # 垂直  預測結果檔
vpath = "/Users/joy/project/final/vec/pd/" #      垂直 存預測匡的文件檔路徑

dfpath = "/Users/joy/project/final/predict_result/deck_result.txt"   # deck  預測結果檔
dpath = "/Users/joy/project/final/deck/pd/"  #  deck  存預測匡的文件檔路徑

hfpath = "/Users/joy/project/final/predict_result/hor_result.txt"   # deck  預測結果檔
hpath = "/Users/joy/project/final/hor/pd/"  #  deck  存預測匡的文件檔路徑

#2. 畫線
imgSPath = "/Users/joy/project/final/deck/pre_line/"
imgS2Path = imgSPath+"90_5/" #存畫出的線

#3. 擬合
linePath = "/Users/joy/project/final/deck/pre_line/90_5/"  ##在第二部畫出的線的座標
intePath = "/Users/joy/project/final/deck/integrate/"   ##擬合的結果路徑

#4. 透視
dis_t = 500
sPath = "/Users/joy/project/final/deck/perspect/"+str(dis_t)+"/"

#5. 畫結果
verGTPath = "/Users/joy/project/final/vec/GT/"
output_folder = "/Users/joy/project/final/demo/" ##最後要展示的檔案


#取得水平預測匡
hf = open(hfpath, 'r')
name=""
# 初始化輸出文件的文件指標和數據字符串
fTxt = None
s = ""

# 遍歷讀取每一行
for line in hf.readlines():
    yolo_datas = line.split()
    
    # 檢查行是否包含 'Predicted'
    if 'Predicted' in line:
        # 如果s中有數據且fTxt已初始化，將其寫入文件並關閉文件
        if s != "" and fTxt is not None:
            fTxt.write(s)
            fTxt.close()
            s = ""  # 重置字符串以準備下一組坐標
        
        # 提取文件名
        name = (line.split("/"))[8].split(".")
        
        # 打開新的文件以寫入提取的文件名
        fTxt = open(hpath + name[0] + ".txt", 'w')
    
    # 檢查行是否包含坐標數據
    if '(left_x:' in yolo_datas:
        index = yolo_datas.index('(left_x:')
        
        # 從行中提取坐標
        left_x = yolo_datas[index + 1]
        top_y = yolo_datas[index + 3]
        width = yolo_datas[index + 5]
        height = yolo_datas[index + 7].split(')')[0]
        
        # 將提取的坐標附加到字符串s
        s += left_x + " " + top_y + " " + width + " " + height + "\n"

# 將s中剩餘的數據寫入最後一個文件並關閉它（如果fTxt已初始化）
if fTxt is not None:
    fTxt.write(s)
    fTxt.close()
    
# 關閉輸入文件
hf.close()



##5.畫結果
def least_squares(y, x_mat):
    a = x_mat.T.dot(x_mat)
    b = x_mat.T.dot(y)
    reg_const = 1e-6  # Adjust the value as needed
    a += reg_const * np.eye(a.shape[0])
    #print(a)
    return np.linalg.solve(a, b)

RED = (0, 0, 255)
GREEN = (0, 255, 0)
BLUE = (255, 0, 0)

tp = 0    
fp = 0
fn = 0

# 垂直方向的處理
for jpgpath in glob.glob(imgpath + '*.[jJ][pP][gG]'): ###########
    #print(jpgpath)
    completejpgname = os.path.basename(jpgpath)
    jpgname = completejpgname.split(".jpg")
    jpgname = completejpgname.split(".jpg") if completejpgname.endswith(".jpg") else completejpgname.split(".JPG")
    img = Image.open(imgpath + completejpgname)
    img1 = cv2.imread(imgpath + completejpgname)
    width, height = img.size
    #print("width:", width, "height:", height)
    predictImg = np.zeros((height, width), dtype=np.int64)
    grounTruth = np.zeros((height, width), dtype=np.int64)
    aboveDeck = np.zeros((height, width), dtype=np.int64)

    GTF = open(verGTPath + jpgname[0] + ".txt", 'r')
    _ver_gt = []
    for line in GTF.readlines():
        line = line.strip("\n")
        line = line.split(" ")
        l = [float(i) for i in line]
        c_x = l[1] * width
        c_y = l[2] * height
        gt_w = l[3] * width
        gt_h = l[4] * height
        lt_x = round(c_x - gt_w / 2)
        lt_y = round(c_y - gt_h / 2)
        rb_x = round(c_x + gt_w / 2)
        rb_y = round(c_y + gt_h / 2)
        _ver_gt.append([lt_x - 1, lt_y - 1, rb_x, rb_y])
        for i in range(lt_x - 1, rb_x):
            for j in range(lt_y - 1, rb_y):
                if (i <= 0 or j <= 0 or i >= width or j >= height):
                    continue
                grounTruth[j][i] = 1
    GTF.close()

    PDF = open(vpath + jpgname[0] + ".txt", 'r')
    _ver_pd = []
    for line in PDF.readlines():
        line = line.strip("\n")
        line = line.split(" ")
        l = [int(i) for i in line]
        _ver_pd.append([l[0] - 1, l[1] - 1, l[0] + l[2], l[1] + l[3]])
        for i in range(l[0] - 1, l[0] + l[2]):
            for j in range(l[1] - 1, l[1] + l[3]):
                if (i <= 0 or j <= 0 or i >= width or j >= height):
                    continue
                predictImg[j][i] = 2
    PDF.close()

    IMG = np.add(predictImg, grounTruth)
    DF = open(intePath + jpgname[0] + ".txt", 'r')
    for line in DF.readlines():
        line = line.strip("\n")
        line = line.strip("[")
        line = line.strip("]")
        line = line.strip(" ")
        line = line.split(",")
        l = [round(float(i)) for i in line]
        X = [l[0], l[2]]
        Y = [l[1], l[3]]
        start_x, start_y, end_x, end_y = X[0], Y[0], X[1], Y[1]
        x_mat = np.c_[np.ones(len(Y)), X]
        w = least_squares(Y, x_mat)
        for i in range(l[0] - 1, l[2]):
            for j in range(0, max(l[1], l[3]) + 1):
                if (i <= 0 or j <= 0 or i >= width or j >= height):
                    continue
                if j > w[0] + w[1] * i:
                    break
                else:
                    aboveDeck[j][i] = 100
        IMG2 = np.add(IMG, aboveDeck)
        _ver_gt.sort(key=lambda gt: gt[0])
        top_line=[]
        down_line = []
        for gt in _ver_gt:
            img_gt_tmp = IMG2[gt[1]: gt[3], gt[0]:gt[2]]
            if np.count_nonzero(img_gt_tmp == 103) != 0: #畫綠線
                top_line.append([gt[0],gt[1]])
                down_line.append([gt[2],gt[3]])
                tp += 1
                #start_x, start_y, end_x, end_y = gt[0], gt[1], gt[2], gt[3]
                #cv2.rectangle(img1,(gt[0], gt[1]), (gt[2], gt[3]),BLUE,thickness=5)
            else:
                #cv2.line(img1,(start_x, start_y), (end_x, end_y),RED,thickness=5)
                if np.count_nonzero(img_gt_tmp == 101) != 0:
                    fn += 1
                    #start_x, start_y, end_x, end_y = gt[0], gt[1], gt[2], gt[3]
                    #cv2.line(img1,(start_x, start_y), (end_x, end_y),RED,thickness=5)
                    
        if len(_ver_gt)==0:
            cv2.line(img1,(start_x, start_y), (end_x, end_y),RED,thickness=80)
        else:
            cv2.line(img1,(start_x, start_y), (end_x, end_y),GREEN,thickness=60)
        
        # cv2.line(img1,(start_x, gt[1]), (end_ver_x ,end_ver_y),GREEN,thickness=5)
        for pd in _ver_pd:
            if np.count_nonzero(img_gt_tmp == 103) != 0: #畫綠線
                top_line.append([pd[0],pd[1]])
                down_line.append([pd[2],pd[3]])
                #cv2.rectangle(img1,(pd[0], pd[1]), (pd[2], pd[3]),RED,thickness=5)
                #cv2.rectangle(img1,(pd[0], pd[1]), (pd[2], pd[3]),BLUE,thickness=5)
            if np.count_nonzero(img_gt_tmp == 103) == 0:
                if np.count_nonzero(img_gt_tmp == 102) != 0:#不畫線
                    fp += 1
                   
        if len(top_line)!=0:
            top_line.sort(key=lambda x: x[0])
            cv2.line(img1,(start_x, top_line[0][1]), (end_x, top_line[-1][1]),GREEN,thickness=60)
            cv2.line(img1,(start_x, top_line[0][1]), (start_x, start_y),GREEN,thickness=60)
            cv2.line(img1,(end_x, top_line[-1][1]), (end_x, end_y),GREEN,thickness=60)
    if tp != 0:
        print("TP: %d, FP: %d, FN: %d" % (tp, fp, fn))
        print("============================================ver")
        Precision = tp / (tp + fp)
        Recall = tp / (tp + fn)
        print("Precision:", Precision)
        print("Recall:", Recall)
        print("F1-score:", Precision * Recall * 2 / (Precision + Recall))    
        fTxt = open("/Users/joy/project/final/final_result.txt", 'w')
        s = "1"
        fTxt.write(s)
        fTxt.close()  
    else:
        print("no guardrail")  
        fTxt = open("/Users/joy/project/final/final_result.txt", 'w')
        s = "0"
        fTxt.write(s)
        fTxt.close()   
           
    # 保存結果
    cv2.imwrite(output_folder+completejpgname, img1)

horImgPath = "/Users/joy/project/final/deck/perspect/500/"
horGTPath = "/Users/joy/project/final/hor/GT/"
# 水平方向的處理
for jpgpath in glob.glob(horImgPath + '*.jpg'):
    print(jpgpath)
    completejpgname = os.path.basename(jpgpath)
    jpgname = completejpgname.split(".jpg")
    img = Image.open(horImgPath + completejpgname)
    width, height = img.size
    print("width:", width, "height:", height)
    predictImg = np.zeros((height, width), dtype=np.int64)
    grounTruth = np.zeros((height, width), dtype=np.int64)

    GTF = open(horGTPath + jpgname[0] + ".txt", 'r')
    _hor_gt = []
    for line in GTF.readlines():
        line = line.strip("\n")
        line = line.split(" ")
        print(line)
        l = [float(i) for i in line]
        c_x = l[0] * width
        c_y = l[1] * height
        gt_w = l[2] * width
        gt_h = l[3] * height
        lt_x = round(c_x - gt_w / 2)
        lt_y = round(c_y - gt_h / 2)
        rb_x = round(c_x + gt_w / 2)
        rb_y = round(c_y + gt_h / 2)
        print("GT:", lt_x, lt_y, rb_x, rb_y)
        _hor_gt.append([lt_x - 1, lt_y - 1, rb_x, rb_y])
        for i in range(lt_x - 1, rb_x):
            for j in range(lt_y - 1, rb_y):
                if (i <= 0 or j <= 0 or i >= width or j >= height):
                    continue
                grounTruth[j][i] = 1
    GTF.close()

    PDF = open("/Users/joy/project/final/hor/pd/" + jpgname[0] + ".txt", 'r')
    _hor_pd = []
    for line in PDF.readlines():
        line = line.strip("\n")
        line = line.split(" ")
        l = [int(i) for i in line]
        print("PD:", l[0], l[1], l[0] + l[2], l[1] + l[3])
        _hor_pd.append([l[0] - 1, l[1] - 1, l[0] + l[2], l[1] + l[3]])
        for i in range(l[0] - 1, l[0] + l[2]):
            for j in range(l[1] - 1, l[1] + l[3]):
                if (i <= 0 or j <= 0 or i >= width or j >= height):
                    continue
                predictImg[j][i] = 2
    PDF.close()

    IMG = np.add(predictImg, grounTruth)
    for gt in _hor_gt:
        lt_x = int(gt[0] * width)
        lt_y = int(gt[1] * height)
        rb_x = int(gt[2] * width)
        rb_y = int(gt[3] * height)
        img_gt_tmp = IMG[lt_y: rb_y, lt_x: rb_x]
        if np.count_nonzero(img_gt_tmp == 3) != 0:
            tp += 1
        else:
            fn += 1
    for pd in _hor_pd:
        lt_x = int(pd[0] * width)
        lt_y = int(pd[1] * height)
        rb_x = int(pd[2] * width)
        rb_y = int(pd[3] * height)
        img_gt_tmp = IMG[lt_y: rb_y, lt_x: rb_x]
        if np.count_nonzero(img_gt_tmp == 3) == 0:
            fp += 1

    print("TP: %d, FP: %d, FN: %d" % (tp, fp, fn))
    print("============================================hor")

# Precision = tp / (tp + fp)
# Recall = tp / (tp + fn)
# print("Precision:", Precision)
# print("Recall:", Recall)
# print("F1-score:", Precision * Recall * 2 / (Precision + Recall))
