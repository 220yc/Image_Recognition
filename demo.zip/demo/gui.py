import tkinter as tk
from tkinter import ttk
from tkinter import *
from tkinter import messagebox
from tkinter.constants import DISABLED, NORMAL
from tkinter import filedialog
from PIL import Image, ImageTk
import os
import shutil
import threading


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()
        # 设置窗口大小和标题
        self.geometry(f"{screen_width}x{screen_height}")
        self.title("Construction Site Safety Guardrail Image Detection System")

        # 创建 Canvas
        self.canvas = tk.Canvas(self, width=screen_width, height=screen_height)
        self.canvas.pack()

        # 添加背景图片
        try:
            self.background_image = Image.open("/Users/joy/darknet-master/demo/bg.png")
            self.background_image = self.background_image.resize((screen_width, screen_height))
            self.background_photo = ImageTk.PhotoImage(self.background_image)

            # 放置背景图片
            self.canvas.create_image(0, 0, anchor="nw", image=self.background_photo)
        except FileNotFoundError:
            print("Error: Background image not found")

        # 添加文字陰影效果
        def add_shadow(text, x, y, font, fill, shadow_offset=1):
            self.canvas.create_text(x-shadow_offset, y-shadow_offset, text=text, font=font, fill='black')
            self.canvas.create_text(x+shadow_offset, y+shadow_offset, text=text, font=font, fill=fill)

        add_shadow("Construction Site Safety Guardrail Image Detection System", 628, 100, ("Arial", 32, "bold"), "white")
        add_shadow("營建工程現場安全護欄影像檢測系統", 635, 150, ("Arial", 28, "bold"), "white")
    

        # 影像输入按鈕
        self.upload_button = tk.Button(self.canvas, text="Upload Image", command=self.upload_image)
        self.upload_button.config(font=("Arial", 18, "bold"), background="gray", foreground="black", relief="ridge", activebackground='#BE77FF', activeforeground='#FFFFFF', state=tk.NORMAL, cursor='heart')
        self.upload_button.place(relx=0.1, rely=0.3)

        # 模型选择
        add_shadow("Select Model:", 570, 270, ("Arial", 22, "bold"), "white")
        self.selected_model = tk.StringVar()
        self.model_options = ["final", "vertical", "deck", "horizontal"]
        self.selected_model.set(self.model_options[0])
        model_menu = tk.OptionMenu(self.canvas, self.selected_model, *self.model_options)
        # 設置下拉式選單選項的字體樣式
        model_menu["menu"].config(font=("Arial", 20, "bold"))
        model_menu.config(font=("Arial", 20, "bold"), foreground="black", highlightthickness=0, background="gray", activebackground='#BE77FF', activeforeground='#FFFFFF', state=tk.NORMAL, cursor='heart')
        model_menu.place(relx=0.52, rely=0.305)

        # 预测按钮
        self.predict_button = tk.Button(self.canvas, text="Detect", command=self.start_preprocessing_thread)
        self.predict_button.config(font=("Arial", 18, "bold"), background="gray", foreground="black", relief="ridge", activebackground='#BE77FF', activeforeground='#FFFFFF', cursor='heart', state=DISABLED)
        self.predict_button.place(relx=0.8, rely=0.3)  # 模型选项的右边
        
        ### 目前狀態
        self.statuslabel = tk.Label(self.canvas, font=("Arial", 24,"bold"), fg="white", text='No image selected!', bg="#919191")  # Change text color to black and make background transparent
        self.statuslabel.place(relx=0.5, rely=0.38, anchor="center")
        
        self.progressbar = ttk.Progressbar(self.canvas, orient="horizontal", length=400, mode="determinate")
        self.progressbar.place(relx=0.5, rely=0.41, anchor="center")

        # 显示影像的Label
        self.image_label = tk.Label(self.canvas)
        self.result_image_label = tk.Label(self.canvas)
        self.result_image_labels = []  
    
    def upload_image(self):
        self.progressbar["value"] = 0
        self.statuslabel.config(text="uploading img!")
        
        if self.image_label:
            self.image_label.destroy()
            self.image_label = tk.Label(self.canvas)
        
        if self.result_image_label:
            self.result_image_label.destroy()
            self.result_image_label = tk.Label(self.canvas)
        
        if self.result_image_labels:
            for label in self.result_image_labels:
                label.destroy()
            self.result_image_labels = []
        
        # 清空显示的图像
        print("nextfile, delete img")
        directories = [
            "/Users/joy/project/final/demo/",
            "/Users/joy/project/final/preprocess/",
            "/Users/joy/project/final/predict_img/",
            "/Users/joy/project/final/hor/hor_predict_img/",
            "/Users/joy/project/final/deck/pre_line/90_5/",
            "/Users/joy/project/final/deck/pd/",
            "/Users/joy/project/final/deck/integrate/",
            "/Users/joy/project/final/deck/perspect/500/",
            "/Users/joy/project/final/vec/pd/",
            "/Users/joy/project/final/vec/draw_pd/",
            "/Users/joy/project/final/hor/draw_pd/",
            "/Users/joy/project/final/vec/pd/",
            "/Users/joy/project/final/hor/pd/" 
        ]
        
        for directory in directories:
            shutil.rmtree(directory, ignore_errors=True)
            os.makedirs(directory, exist_ok=True)

        image_path = filedialog.askopenfilename(
            initialdir="/Users/joy/project/final/all/", 
            title="Select Image",
            filetypes=(("Image Files", "*.jpg *.JPG"))
        )
    
        # 如果未选择图像文件，则显示警告并返回
        if not image_path:
            messagebox.showwarning("Warning", "Please select an image.")
            self.statuslabel.config(text="No image selected!")
            self.predict_button.config(state=tk.DISABLED)
            return
        
        if image_path:
            print("picture selected!!!!")
            # 保存影像到预测文件夹
            predict_folder = "/Users/joy/project/final/predict_img/"
            os.makedirs(predict_folder, exist_ok=True)
            shutil.copy(image_path, predict_folder)
            
            predict_txt_path = "/Users/joy/project/final/predict.txt"
            with open(predict_txt_path, "w") as f:
                for filename in os.listdir(predict_folder):
                    file_path = os.path.join(predict_folder, filename)
                    f.write(file_path + "\n")
            
            # 显示上传的图像
            self.display_uploaded_image(image_path)
            self.predict_button.config(state=tk.NORMAL)
            self.statuslabel.config(text="img uploaded!")
            
    def start_preprocessing_thread(self):
        threading.Thread(target=self.preprocessing).start()
            
    def preprocessing(self):
        self.upload_button.config(state=tk.DISABLED)
        self.predict_button.config(state=tk.DISABLED)
        self.statuslabel.config(text="clean folder......")
        self.progressbar["value"] = 10
        os.system("rm -rf /Users/joy/project/final/demo/*")      
        os.system("rm -rf /Users/joy/project/final/preprocess/*")    
        
        os.system("rm -rf /Users/joy/project/final/hor/hor_predict_img/*")    
        os.system("rm -rf /Users/joy/project/final/deck/pre_line/90_5/*")    
        os.system("rm -rf /Users/joy/project/final/deck/pd/*")  
        os.system("rm -rf /Users/joy/project/final/deck/integrate/*")  
        os.system("rm -rf /Users/joy/project/final/deck/perspect/500/*")  
        os.system("rm -rf /Users/joy/project/final/vec/pd/*") 
        os.system("rm -rf /Users/joy/project/final/hor/pd/*") 
         
        self.update_idletasks()  # 立即更新界面状态  
        # 检查是否上传了图像
        upload_folder = False
        if upload_folder:
            messagebox.showwarning("Warning", "Please upload an image.")
            return
        else:
            if self.result_image_label:
                self.result_image_label.destroy()
                self.result_image_label = tk.Label(self.canvas)
        
            if self.result_image_labels:
                for label in self.result_image_labels:
                    label.destroy()
                self.result_image_labels = []
                
            # 执行影像强化
            self.statuslabel.config(text="preprocessing......")
            os.system("python demo/clahe_RGB_final0.py")            
            os.system("ls /Users/joy/project/final/preprocess/* > /Users/joy/project/final/preprocess.txt")
            self.progressbar["value"] = 20
            # 根据选择的模型执行相应操作
            selected_model = self.selected_model.get()
            if selected_model == "final":
                # 显示结果影像的Label
                print("detect complete guardrail......")      
                self.final_detect()
                self.progressbar["value"] = 100
                self.statuslabel.config(text="final result is below!") 
            
            elif selected_model == "vertical":
                self.statuslabel.config(text="detecting vertical guardrail......")                
                print("detect vertical")
                self.vertical_guardrail()
                self.progressbar["value"] = 100
                self.statuslabel.config(text="vertical result is below!") 
 
            elif selected_model == "deck":
                self.statuslabel.config(text="detecting deck......") 
                print("detect deck") 
                self.deck_guardrail()
                self.progressbar["value"] = 100
                self.statuslabel.config(text="deck result is below!") 

            elif selected_model == "horizontal":
                self.statuslabel.config(text="preprocessing.......")  
                print("detect horizontal")
                self.horizontal_guardrail()
                self.progressbar["value"] = 100
                self.statuslabel.config(text="horizontal result is below!") 
                
            self.upload_button.config(state= NORMAL)
            self.predict_button.config(state= NORMAL)

    def vertical_guardrail(self):
        self.progressbar["value"] = 30
        preprocess_folder = "/Users/joy/project/final/preprocess/"
        preprocess_images = [file for file in os.listdir(preprocess_folder) if file.lower().endswith(".jpg") and file != ".DS_Store"]
            # 取第一个图像文件
        result_image_path = os.path.join(preprocess_folder, preprocess_images[0])
        command = f"./darknet detector test /Users/joy/darknet-master/guardrail/vec/obj.data /Users/joy/darknet-master/guardrail/vec/yolov4-obj.cfg /Users/joy/darknet-master/guardrail/vec/backup/vec.weights -thresh 0.5 -iou_thresh 0.1 {result_image_path}"
        os.system(command)            
        self.progressbar["value"] = 80
        print("vertical done!")
        #self.result_image_label.grid(row=1, column=0, columnspan=5, pady=5)
        # 显示结果影像
        self.result_image_label.place(relx=0.75, rely=0.7, anchor="center")
        show_images = "/Users/joy/darknet-master/predictions.jpg"
        self.statuslabel.config(text="processing......")
        if show_images:
            resized_photo = self.resize_image(show_images, 512, 512)
            result_photo = ImageTk.PhotoImage(resized_photo)
            self.result_image_label.configure(image=result_photo)
            self.result_image_label.image = result_photo
        #os.system("rm -rf /Users/joy/darknet-master/predictions.jpg")  

    
    def deck_guardrail(self):
        self.progressbar["value"] = 30
        preprocess_folder = "/Users/joy/project/final/preprocess/"
        preprocess_images = [file for file in os.listdir(preprocess_folder) if file.lower().endswith(".jpg") and file != ".DS_Store"]
        print(preprocess_images)
        if preprocess_images:
            # 取第一个图像文件
            # result_image_path = os.path.join(preprocess_folder, preprocess_images[0])
            # command = f"./darknet detector test /Users/joy/darknet-master/guardrail/deck/obj.data /Users/joy/darknet-master/guardrail/deck/yolov4-obj.cfg /Users/joy/darknet-master/guardrail/deck/backup/deck.weights -thresh 0.1 -iou_thresh 0.2 {result_image_path}"
            # os.system(command)
            os.system("./darknet detector test /Users/joy/darknet-master/guardrail/deck/obj.data /Users/joy/darknet-master/guardrail/deck/yolov4-obj.cfg /Users/joy/darknet-master/guardrail/deck/backup/deck.weights -thresh 0.1 -iou_thresh 0.2 -dont_show -ext_output < /Users/joy/project/final/preprocess.txt > /Users/joy/project/final/predict_result/deck_result.txt")
            self.progressbar["value"] = 80
            print("deck done!")
            os.system("python demo/drawline_integrate.py")
            # 显示结果影像的Label
            #self.result_image_label = tk.Label(self.canvas)
            self.result_image_label.place(relx=0.75, rely=0.7, anchor="center")
            # 显示结果影像
        preprocess_folder = "/Users/joy/project/final/deck/integrate/"
        preprocess_images = [file for file in os.listdir(preprocess_folder) if file.lower().endswith((".jpg"))]
        if preprocess_images:
            # 取第一个图像文件
            result_image_path = os.path.join(preprocess_folder, preprocess_images[0])
            resized_photo = self.resize_image(result_image_path, 512, 512)
            result_photo = ImageTk.PhotoImage(resized_photo)
            self.result_image_label.configure(image=result_photo)
            self.result_image_label.image = result_photo 
        #os.system("rm -rf /Users/joy/darknet-master/predictions.jpg")  
   
    def horizontal_guardrail(self):
        self.progressbar["value"] = 30
        self.statuslabel.config(text="detecting vertical guardrail......")
        os.system("./darknet detector test /Users/joy/darknet-master/guardrail/vec/obj.data /Users/joy/darknet-master/guardrail/vec/yolov4-obj.cfg /Users/joy/darknet-master/guardrail/vec/backup/vec.weights -thresh 0.5 -iou_thresh 0.1 -dont_show -ext_output < /Users/joy/project/final/preprocess.txt > /Users/joy/project/final/predict_result/vec_result.txt")
        os.system("python demo/draw_ver.py")
        print("vertical done!")
        self.show_result_img("/Users/joy/project/final/vec/draw_pd/")
        self.progressbar["value"] = 40
        
        self.statuslabel.config(text="detecting deck......")
        os.system("./darknet detector test /Users/joy/darknet-master/guardrail/deck/obj.data /Users/joy/darknet-master/guardrail/deck/yolov4-obj.cfg /Users/joy/darknet-master/guardrail/deck/backup/deck.weights -thresh 0.1 -iou_thresh 0.2 -dont_show -ext_output < /Users/joy/project/final/preprocess.txt > /Users/joy/project/final/predict_result/deck_result.txt")
        os.system("python demo/drawline_integrate.py")
        print("deck done!")
        self.show_result_img("/Users/joy/project/final/deck/integrate/")
        self.progressbar["value"] = 50
        
        self.statuslabel.config(text="perspective......")
        os.system("python demo/perspective.py")
        print("get hor done!")
        self.result_image_label.destroy()
        self.display_result_images("/Users/joy/project/final/deck/perspect/500/")
        self.progressbar["value"] = 60
        
        self.progressbar["value"] = 70
        image_folder = "/Users/joy/project/final/deck/perspect/500/"
        image_files = [file for file in os.listdir(image_folder) if file.lower().endswith((".jpg"))and file != ".DS_Store"]
        if image_files:
            self.statuslabel.config(text="detecting horizontal guardrail.......") 
            for i, image_file in enumerate(image_files):
                image_path = os.path.join(image_folder, image_file)
                command = f"./darknet detector test /Users/joy/darknet-master/guardrail/hor/obj.data /Users/joy/darknet-master/guardrail/hor/yolov4-obj.cfg /Users/joy/darknet-master/guardrail/hor/backup/hor.weights -thresh 0.2 -iou_thresh 0.1 {image_path}"
                os.system(command)
                print(f"hor_{i}_done!!")
                images = "/Users/joy/darknet-master/predictions.jpg"
                if images:
                # 保存影像到预测文件夹
                    hor_predict_folder = "/Users/joy/project/final/hor/hor_predict_img/"
                    os.makedirs(hor_predict_folder, exist_ok=True)
                    os.system(f"cp {images} {hor_predict_folder}{image_file}")  # 保存为相同的文件名
                # 更新界面上的所有結果圖像
            for label in self.result_image_labels:
                label.destroy()
            self.display_result_images(hor_predict_folder)
            self.progressbar["value"] = 80
        else:
            messagebox.showwarning("Warning", "No Detect Hor_Guardrail.")
            return
            

    def display_result_images(self,image_folder):
        self.result_image_labels = []
        
        image_files = [file for file in os.listdir(image_folder) if file.lower().endswith(".jpg") and file != ".DS_Store"]
        # 指定起始位置的相對 Y 座標
        if len(image_files)==1:
            rely_position = 0.52 #1
            width=512
            height=512
        elif len(image_files)==2:
            rely_position = 0.42 #2
            width=450
            height=180
        elif len(image_files)==3:
            rely_position = 0.35 #3
            width=400
            height=140
        # 計算每個影像標籤的高度
        for idx, image_file in enumerate(image_files):
            # 創建影像的Label
            result_image_label = tk.Label(self.canvas)
            result_image_path = os.path.join(image_folder, image_file)
            #result_image = Image.open(result_image_path)
            #width, height = result_image.size
            # 計算影像標籤應該放置的位置
            rely_position = rely_position + 0.18
            # 設置影像標籤的位置，依序排列在 Y 方向上
            result_image_label.place(relx=0.75, rely=rely_position, anchor="center")
            self.result_image_labels.append(result_image_label)

        # 處理影像並將其顯示在標籤中
            #result_image.thumbnail((width, height))
            result_image = self.resize_image(result_image_path, width, height)
            result_photo = ImageTk.PhotoImage(result_image)
            result_image_label.configure(image=result_photo)
            result_image_label.image = result_photo
            

            
    def final_detect(self):
        self.progressbar["value"] = 30
        self.show_result_img("/Users/joy/project/final/preprocess/")
        
        self.statuslabel.config(text="detecting vertical guardrail......")
        os.system("./darknet detector test /Users/joy/darknet-master/guardrail/vec/obj.data /Users/joy/darknet-master/guardrail/vec/yolov4-obj.cfg /Users/joy/darknet-master/guardrail/vec/backup/vec.weights -thresh 0.5 -iou_thresh 0.1 -dont_show -ext_output < /Users/joy/project/final/preprocess.txt > /Users/joy/project/final/predict_result/vec_result.txt")
        os.system("python demo/draw_ver.py")
        print("vertical done!")
        self.show_result_img("/Users/joy/project/final/vec/draw_pd/")
        self.progressbar["value"] = 40
        
        self.statuslabel.config(text="detecting deck......")
        os.system("./darknet detector test /Users/joy/darknet-master/guardrail/deck/obj.data /Users/joy/darknet-master/guardrail/deck/yolov4-obj.cfg /Users/joy/darknet-master/guardrail/deck/backup/deck.weights -thresh 0.1 -iou_thresh 0.2 -dont_show -ext_output < /Users/joy/project/final/preprocess.txt > /Users/joy/project/final/predict_result/deck_result.txt")
        os.system("python demo/drawline_integrate.py")
        print("deck done!")
        self.show_result_img("/Users/joy/project/final/deck/integrate/")
        self.progressbar["value"] = 50
        
        self.statuslabel.config(text="perspective......")
        os.system("python demo/perspective.py")
        print("get hor done!")
        self.result_image_label.destroy()
        self.display_result_images("/Users/joy/project/final/deck/perspect/500/")
        self.progressbar["value"] = 60
        
        self.statuslabel.config(text="detecting horizontal guardrail.......")  
        os.system("ls /Users/joy/project/final/deck/perspect/500/* > /Users/joy/project/final/hor/hor.txt")
        command = f"./darknet detector test /Users/joy/darknet-master/guardrail/hor/obj.data /Users/joy/darknet-master/guardrail/hor/yolov4-obj.cfg /Users/joy/darknet-master/guardrail/hor/backup/hor.weights -thresh 0.2 -iou_thresh 0.1 -dont_show -ext_output < /Users/joy/project/final/hor/hor.txt > /Users/joy/project/final/predict_result/hor_result.txt"
        os.system(command)
        
        os.system("python demo/draw_hor.py")
        for label in self.result_image_labels:
                label.destroy()
        self.display_result_images("/Users/joy/project/final/hor/draw_pd/")
        self.progressbar["value"] = 70
        
        self.statuslabel.config(text="detecting complete guardrail.......")  
        os.system("python demo/demo.py")
        self.statuslabel.config(text="processing......")
        self.progressbar["value"] = 80
        for label in self.result_image_labels:
                label.destroy()
        self.result_image_label = tk.Label(self.canvas)
        self.show_result_img("/Users/joy/project/final/demo/")
            
        with open("/Users/joy/project/final/final_result.txt", 'r') as file:
            content = file.read().strip()
        # 判断内容是否为数字0
        if content == '0':
            messagebox.showwarning("Warning", "Improperly installed safety guardrail!!")
            return
            
    def display_uploaded_image(self, image_path):
        # 显示上传的图像
        # 显示上传的图像
        self.image_label.place(relx=0.25, rely=0.7, anchor="center")
        #self.image_label.grid(row=1, column=0, columnspan=5, pady=5)
        image = self.resize_image(image_path, 512, 512)
        photo = ImageTk.PhotoImage(image)
        self.image_label.configure(image=photo)
        self.image_label.image = photo
        

        
    def resize_image(self, image_path, max_width, max_height):
        # 將影像按比例縮小並設置為Tkinter的PhotoImage對象
        image = Image.open(image_path)
        width, height = image.size
        # 計算新的寬度和高度以保持比例
        ratio = min(max_width / width, max_height / height)
        new_width = int(width * ratio)
        new_height = int(height * ratio)
        # 使用LANCZOS濾波器進行縮放
        resized_image = image.resize((new_width, new_height), Image.LANCZOS)
        return resized_image

    def show_result_img(self, img_folder):
        # 显示结果影像
        # 显示结果影像的Label
        #self.result_image_label = tk.Label(self.canvas)
        self.result_image_label.place(relx=0.75, rely=0.7, anchor="center")
        image = [file for file in os.listdir(img_folder) if file.lower().endswith((".jpg"))]
        if image:
            # 取第一个图像文件
            result_image_path = os.path.join(img_folder, image[0])
            resized_photo = self.resize_image(result_image_path, 512, 512)
            result_photo = ImageTk.PhotoImage(resized_photo)
            self.result_image_label.configure(image=result_photo)
            self.result_image_label.image = result_photo 
            
if __name__ == "__main__":
    app = App()
    app.mainloop()
