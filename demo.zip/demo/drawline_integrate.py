'''
needing file
1,要做的影像 ./final/predict_img/

2.預測結果 ./final/predict_result/
-- ./final/predict_result/guardrail_result.txt
-- ./final/predict_result/deck_result.txt

3.畫線
imgSPath = "./final/deck/pre_line/"
imgS2Path = imgSPath+"90_5/" #存畫出的線

4.擬合 
intePath = "./final/deck/pre_line/integrate/"   ##擬合的結果路徑

5.透視
sPath = "./final/deck/perspect"+str(dis_t)+"/"

6.demo
output_folder = "./final/demo/"

verGTPath = "/Users/joy/project/GroundTrue/"
horImgPath = "/Users/joy/project/hor_HE/data_from_zeng/"
horGTPath = "/Users/joy/project/hor_HE/data_from_zeng/"

'''
import glob
import os.path
from PIL import Image, ImageDraw
import math
import numpy as np
import heapq
import pandas as pd
import time
import math
from scipy.spatial import distance
import cv2
import matplotlib.pyplot as plt
import math
import os
import string
import sys
from math import *


imgpath = '/Users/joy/project/final/predict_img/' #要處理的影像
#1 取匡
dfpath = "/Users/joy/project/final/predict_result/deck_result.txt"   # deck  預測結果檔
dpath = "/Users/joy/project/final/deck/pd/"  #  deck  存預測匡的文件檔路徑
#2. 畫線
imgSPath = "/Users/joy/project/final/deck/pre_line/"
imgS2Path = imgSPath+"90_5/" #存畫出的線

#3. 擬合
linePath = "/Users/joy/project/final/deck/pre_line/90_5/"  ##在第二部畫出的線的座標
intePath = "/Users/joy/project/final/deck/integrate/"   ##擬合的結果路徑

#1.拿到預測匡
# 打開預測結果文件
df = open(dfpath, 'r')
s = ""
fTxt = None

for line in df.readlines():
    yolo_datas = line.split()
    
    # 檢查行是否包含 'Predicted'
    if 'Predicted' in line:
        # 如果s中有數據且fTxt已初始化，將其寫入文件並關閉文件
        if s != "" and fTxt is not None:
            fTxt.write(s)
            fTxt.close()
            s = ""  # 重置字符串以準備下一組坐標
        
        # 提取文件名
        name = (line.split("/"))[6].split(".")
        
        # 打開新的文件以寫入提取的文件名
        fTxt = open(dpath + name[0] + ".txt", 'w')
    
    # 檢查行是否包含坐標數據
    if '(left_x:' in yolo_datas:
        index = yolo_datas.index('(left_x:')
        
        # 從行中提取坐標
        left_x = yolo_datas[index + 1]
        top_y = yolo_datas[index + 3]
        width = yolo_datas[index + 5]
        height = yolo_datas[index + 7].split(')')[0]
        
        # 將提取的坐標附加到字符串s
        s += "0 " + left_x + " " + top_y + " " + width + " " + height + "\n"

# 將s中剩餘的數據寫入最後一個文件並關閉它（如果fTxt已初始化）
if fTxt is not None:
    fTxt.write(s)
    fTxt.close()

# 關閉輸入文件
df.close()


#2.畫線
####deck畫線
def least_squares(y, x_mat):
    a = x_mat.T.dot(x_mat)
    b = x_mat.T.dot(y)
    reg_const = 1e-6  # Adjust the value as needed
    a += reg_const * np.eye(a.shape[0])
    #print(a)
    return np.linalg.solve(a, b)

def getNewDist(p1, p2):
    p = [p1, p2]
#     print(p)
    p.sort(key=lambda p:p[1])
#     print(p)

    X=[]
    Y=[]
    X.append(p[0][1]+p[0][3]/2)
    Y.append(p[0][2]+p[0][4]/2)
    X.append(p[1][1]+p[1][3]/2)
    Y.append(p[1][2]+p[1][4]/2)
#     print("X:", X)
#     print("Y:", Y)
#     print("index", X.index(min(X)))
    minIdx = X.index(min(X))
    maxIdx = X.index(max(X))
    n = len(Y)
    x_mat = np.c_[np.ones(n), X]
    w = least_squares(Y, x_mat)
#     print("w:", w)
    #Y = w[0]+w[1]*X
    n = 0  #距離
    n_1 = 0#在BOX1內的點
    n_2 = 0#在BOX2內的點
    n_3 = 0#重疊距離

    Dw = abs(X[maxIdx]-X[minIdx])
    Dh = abs(Y[Y.index(max(Y))]-Y[Y.index(min(Y))])
    
#     print("Dw v.s. Dh: %.1f v.s. %.1f" %(Dw, Dh))

    if Dw>=Dh:
        for i in range(round(X[minIdx]), round(X[maxIdx]+1)):
    #         print(i)
            tmpY = w[0]+w[1]*i
            if Y[0] == Y[1]:
                if i<p[minIdx][1]+p[minIdx][3]:
                    n_1 += 1
                elif i>p[maxIdx][1]:
                    n_2 += 1
                else:
                    n += 1
            elif minIdx == Y.index(min(Y)):
                if tmpY<p[minIdx][2]+p[minIdx][4] and i<p[minIdx][1]+p[minIdx][3]:
        #             print(tmpY, "<", p[minIdx][2]+p[minIdx][4])
                    n_1 += 1
                elif tmpY>p[maxIdx][2] and i>p[maxIdx][1]:
        #             print(tmpY, ">", p[maxIdx][2])
                    n_2 += 1
                else:
                    n += 1
        #         print("==================")
            else:
                if tmpY>p[minIdx][2] and i<p[minIdx][1]+p[minIdx][3]:
        #             print(tmpY, "<", p[minIdx][2]+p[minIdx][4])
                    n_1 += 1
                elif tmpY<p[maxIdx][2]+p[maxIdx][4] and i>p[maxIdx][1]:
        #             print(tmpY, ">", p[maxIdx][2])
                    n_2 += 1
                else:
                    n += 1
        #         print("==================")

#         print(X[maxIdx]-X[minIdx]+1)
#         print("n1 =", n_1)
        if n==0:
            for i in range(round(X[minIdx]), round(X[maxIdx]+1)):
                tmpY = w[0]+w[1]*i
                if Y[0] == Y[1]:
                    if i<p[minIdx][1]+p[minIdx][3] and i>p[maxIdx][1]:
                        n_3 -= 1
                elif minIdx == Y.index(min(Y)):
                    if tmpY<p[minIdx][2]+p[minIdx][4] and i<p[minIdx][1]+p[minIdx][3] and tmpY>p[maxIdx][2] and i>p[maxIdx][1]:
                        n_3 -= 1
                else:
                    if tmpY>p[minIdx][2] and i<p[minIdx][1]+p[minIdx][3] and tmpY<p[maxIdx][2]+p[maxIdx][4] and i>p[maxIdx][1]:
                        n_3 -= 1

        #     n = -(getDist(X[minIdx], w[0]+w[1]*X[minIdx], X[maxIdx], w[0]+w[1]*X[maxIdx]))
#             print("n_3 =", n_3)
            return n_3
        else:
#             print("n =", n)
            return n
#         print("n2 =", n_2)
    else:
#         print("Dw<Dh")   
        minIdx = Y.index(min(Y))
        maxIdx = Y.index(max(Y))
        for i in range(round(Y[minIdx]), round(Y[maxIdx]+1)):
    #         print("Y:", i)
            tmpX = (i-w[0])/w[1]
#             print(tmpX)
    #         print("min:", p[minIdx][1]+p[minIdx][3], "max:", p[maxIdx][1])
#             print("minIdx v.s maxIdx:", minIdx, maxIdx)
            if X[0]==X[1]:
                if i<p[minIdx][2]+p[minIdx][4]:
                    n_1 += 1
                elif i>p[maxIdx][2]:
                    n_2 +=2
                else:
                    n +=1                
                #print(w)
            elif minIdx == X.index(min(X)):
                if tmpX<p[minIdx][1]+p[minIdx][3] and i<p[minIdx][2]+p[minIdx][4]:
                    n_1 += 1
                elif tmpX>p[maxIdx][1] and i>p[maxIdx][2]:
                    n_2 += 1
                else:
                    n += 1
        #         print("================")
            else:
                if tmpX>p[minIdx][1] and i<p[minIdx][2]+p[minIdx][4]:
                    n_1 += 1
                elif tmpX<p[maxIdx][1]+p[maxIdx][3] and i>p[maxIdx][2]:
                    n_2 += 1
                else:
                    n += 1

#         print(Y[maxIdx]-Y[minIdx]+1)        
#         print("n1 =", n_1)
        if n==0:
            for i in range(round(Y[minIdx]), round(Y[maxIdx]+1)):
                tmpX = (i-w[0])/w[1]
                if X[0]==X[1]:
                    if i>p[maxIdx][2] and i<p[minIdx][2]+p[minIdx][4]:
                        n_3 -= 1
                elif minIdx == X.index(min(X)):
                    if tmpX<p[minIdx][1]+p[minIdx][3] and i<p[minIdx][2]+p[minIdx][4] and tmpX>p[maxIdx][1] and i>p[maxIdx][2]:
                        n_3 -= 1
                else:
                    if tmpX>p[minIdx][1] and i<p[minIdx][2]+p[minIdx][4] and tmpX<p[maxIdx][1]+p[maxIdx][3] and i>p[maxIdx][2]:
                        n_3 -= 1

        #     n = -(getDist(X[minIdx], w[0]+w[1]*X[minIdx], X[maxIdx], w[0]+w[1]*X[maxIdx]))
#             print("n_3 =", n_3)
            return n_3
        else:
#             print("n =", n)
            return n
#         print("n2 =", n_2)

        
# path = "/Users/joy/project/deck_HE/GT_predict/" #deck的預測匡
# imgpath = '/Users/joy/project/IMG/' #要畫線的影像
# imgSPath = "/Users/joy/project/deck_HE/pre_line/"
# imgS2Path = imgSPath+"90_5/" #存畫出的線
n=0
tolerance = 300
angleT = 10

for Tpath in glob.glob(dpath + '*.txt'):
    n+=1
#     if(n!=8):continue
    #print(Tpath)
    completename=os.path.basename(Tpath)
#     print("File-Name_with_extension：",completename) #取得檔案完整名稱
    jpgname=completename.split(".txt")
#     print("File-Name：",jpgname[0])      #取得檔案名
    img = Image.open(imgpath+jpgname[0]+".jpg") 
    img2 = img

    TF = open(Tpath, 'r')
    point = []
    pData = []
    connect = []
    drawLine = []
#     drawnP = []
#     dLine = []
    for line in TF.readlines():
        line = line.strip('\n')
#         print(line)
        data = line.split(" ")
        pData.append([float(x) for x in data])
#         print("Data:", [float(x) for x in data])
    dist = np.zeros([len(pData), len(pData)])
    drawnP = np.zeros(len(pData))
    pData.sort(key=lambda pData:pData[0])
    pData.sort(key=lambda pData:pData[1])
#     print("pData:", pData)
    #draw predicted deck
    draw = ImageDraw.Draw(img)
    for bbox in pData:
        left_x, top_y, width, height = bbox[1], bbox[2], bbox[3], bbox[4]
        draw.rectangle([left_x, top_y, left_x + width, top_y + height], outline="yellow", width=5)

    for p in pData:
#         print(p)
        tmp= []
        tmp.append(int(p[1])+(int(p[3])/2))
        tmp.append(int(p[2])+(int(p[4])/2))
#         print("tmp:", tmp, "\n")
        point.append(tmp)
#     print(point)
    for X in range(len(pData)):
        for Y in range(len(pData)):
            if X == Y:
                continue
            dist[X][Y] = getNewDist(pData[X],pData[Y])
#     pData_pd = pd.DataFrame (pData)
#     print(pData_pd)
    pd.set_option('display.max_columns', None)
#     dist_pd = pd.DataFrame (dist)
#     print(dist_pd)
#     for i in dist:
#         print(i)
#     print(dist)
    smallest3 = []
    for i in range(len(dist)):
#         print("===========================%d=======================" %i)
#         print("3 largest:", smallest3, type(smallest3))
        lDist = list(dist[i])
#         print(lDist)
        tT = [i for i in lDist if i<tolerance]
        sTmp = lDist.copy()
        tmpN=0
        tmp = []
        tS = heapq.nsmallest(len(tT), lDist) #符合範圍的距離
#         print("tS:", tS)
        for t in tS:
            if t != 0:
                if lDist.index(t)!= 0:
                    tmp.append(lDist.index(t))
                else:
                    tmp.append(len(point))
            else:
                if sTmp.index(0)+tmpN == i:
                    sTmp.remove(0)
                    tmpN += 1
                else:
                    if sTmp.index(0)+tmpN != 0:
                        tmp.append(sTmp.index(0)+tmpN)
                    else:
                        tmp.append(len(point))
                    sTmp.remove(0)
                    tmpN += 1
#                 print(sTmp, tmpN)
#         print("tmp:", tmp)
        connect.append(tmp)            

    #print("=================\nconnect:",connect,"\n=================")
    
    for i in range(len(connect)):
#         print("================%d================" %i)
        if connect[i] == []:
            continue
#         print(i,":",connect[i])
#         drawB=True
        for j in range(len(connect[i])):
    #         print("drawnP[connect[i][0]] =%d " %drawnP[connect[i][0]],"drawnP[i]:", drawnP[i], "connect[i][0]:", connect[i][0])
            tmpCIJ = connect[i][j]
            if tmpCIJ == len(point):
                tmpCIJ=0
            if drawnP[tmpCIJ] == 0 and drawnP[i] != connect[i][j]:
#                 print("drawnP[connect[i][0]] == 0 and drawnP[i] != connect[i][0]")
    # point[connect[i][j]][0]=>要判斷connect[i][j]是否等於len(connect)=>若等於的話要改成point[0][0]
                if connect[i][j] != len(point):
                    PaX = point[connect[i][j]][0]
                    PaY = point[connect[i][j]][1]
                else:
                    PaX = point[0][0]
                    PaY = point[0][1]
                PX = point[i][0]
                PY = point[i][1]
    #             判斷角度ˇ
#                 print("drawnP:",drawnP)
#                 print("drawnP[%d]:" %i,drawnP[i])
                if drawnP[i] != 0:
                    if drawnP[i] == len(connect): #0的位置是記成len(connect)
                        PcX = point[0][0]
                        PcY = point[0][1]          
                    else:
                        PcX = point[int(drawnP[i])][0]
                        PcY = point[int(drawnP[i])][1]
                    dAx = PaX - PX
                    if dAx == 0:
                        dAx=0.001
                    dCx = PcX - PX
                    if dCx == 0:
                        dCx=0.001
                    mA = (PaY - PY)/dAx
                    mC = (PcY - PY)/dCx
                    tan = (mA-mC)/(1+(mA*mC))
                    atan = math.atan(tan)
                    angle = atan*180.0/math.pi
                    if angle<0:
                        angle = abs(angle)
#                     print("a1:", angle)
                    if(angle<angleT or angle>(180-angleT)):
        #             判斷角度^
    #                     draw = ImageDraw.Draw(img)
                        shape1 = [PaX, PaY, PX, PY]
    #                     draw.line(shape1, fill="cyan", width=15)
    #                     print("red")
                        if i == 0:
    #? point[connect[i][j]][0]=>要判斷connect[i][j]是否等於len(connect)=>若等於的話要改成point[0][0]
                            if connect[i][j] != len(point):
                                drawnP[connect[i][j]] = len(connect)
                            else:
                                drawnP[0] = len(connect)
                        else:
    #? point[connect[i][j]][0]=>要判斷connect[i][j]是否等於len(connect)=>若等於的話要改成point[0][0]
                            if connect[i][j] != len(point):
                                drawnP[connect[i][j]] = i
                            else:
                                drawnP[0] = i
#                         print("draw", i, "to", connect[i][j])
#                         print("shape1:", shape1)
                        drawLine.append(shape1)
    #                     drawB = False
#                         continue
                        break
                else:
                    lDP = list(drawnP)
#                     print(lDP)
                    if lDP.count(connect[i][j])!=0: #要被畫的那點是否畫過別點
#                         print("HELP!HELP!HELP!HELP!HELP!HELP!HELP!HELP!HELP!HELP!HELP!HELP!HELP!HELP!")
#                         tmpCIJ = connect[i][j]
#                         if tmpCIJ == len(point):
#                             tmpCIJ=0
                        PcX = point[lDP.index(connect[i][j])][0]
                        PcY = point[lDP.index(connect[i][j])][1]          
# =================================ctrl+V
                        dAx = PcX - PaX
                        if dAx == 0:
                            dAx=0.001
                        dCx = PX - PaX
                        if dCx == 0:
                            dCx=0.001
                        mA = (PcY - PaY)/dAx
                        mC = (PY - PaY)/dCx
                        tan = (mA-mC)/(1+(mA*mC))
                        atan = math.atan(tan)
                        angle = atan*180.0/math.pi
                        if angle<0:
                            angle = abs(angle)
#                         print("a1:", angle)
                        if(angle<angleT or angle>(180-angleT)):
            #             判斷角度^
                            shape1 = [PX, PY, PaX, PaY]
                            if i == 0:
                                if connect[i][j] != len(point):
                                    drawnP[connect[i][j]] = len(connect)
                                else:
                                    drawnP[0] = len(connect)
                            else:
                                if connect[i][j] != len(point):
                                    drawnP[connect[i][j]] = i
                                else:
                                    drawnP[0] = i
#                             print("draw", i, "to", connect[i][j])
#                             print("shape1:", shape1)
                            drawLine.append(shape1)
        #                     drawB = False
    #                         continue
                            break
# =================================ctrl+V
    #                     draw = ImageDraw.Draw(img)
                    else:
                        shape1 = [PaX, PaY, PX, PY]
                        if i == 0:
                            if connect[i][j] != len(point):
                                drawnP[connect[i][j]] = len(connect)
                            else:
                                drawnP[0] = len(connect)
                        else:
                            if connect[i][j] != len(point):
                                drawnP[connect[i][j]] = i
                            else:
                                drawnP[0] = i

#                         print("Draw", i, "to", connect[i][j])
#                         print("shape1:", shape1)
                        drawLine.append(shape1)
    #                     drawB = False
#                         continue
                        break
            
    fTXT = open(imgS2Path+jpgname[0]+".txt", 'w')
    strDrawLine = [str(drawLine[t])+"\n" if t!=len(drawLine)-1 else str(drawLine[t]) for t in range(len(drawLine))]
#     print(strDrawLine)
    fTXT.writelines(strDrawLine)
    fTXT.close()        
    #print("=================\nline:",drawLine,"\n=================")
    
    draw = ImageDraw.Draw(img)
    for sn in range(len(drawLine)):
#         draw.line(drawLine[sn], fill=(1*sn,10*sn,5 *sn), width=15) 
        draw.line(drawLine[sn], fill="cyan", width=15)
#     img.show()
    img.save(imgS2Path+jpgname[0]+".jpg")
    #print("===============%d================\n" %n)


##3.deck線段擬合
def calAngle(line):
    x1, y1, x2, y2 = line
    if x1 > x2:
        tmp = x1
        tmp2 = y1
        x1 = x2
        y1 = y2
        x2 = tmp
        y2 = tmp2
    sT1= x2-x1
    if sT1==0:
        sT1 = 0.001
        #print("in")
    slope1 = (y2-y1)/sT1
    a1 = math.degrees(math.atan(slope1))
#     print(a1)
    return round(a1)

def least_squares(y, x_mat):
    a = x_mat.T.dot(x_mat)
    b = x_mat.T.dot(y)
    return np.linalg.solve(a, b)

# imgpath = "/Users/joy/project/IMG/"  ##要擬和的影像
# linePath = "/Users/joy/project/deck_HE/pre_line/90_5/"  ##在第二部畫出的線的座標
# intePath = "/Users/joy/project/deck_HE/pre_line/integrate0430/"   ##擬合的結果路徑

angleT = 15
disT = 300
for jpgpath in glob.glob(linePath + '*.jpg'):
    #print(jpgpath)
    completejpgname=os.path.basename(jpgpath)
#     print("File-Name_with_extension：",completejpgname) #取得檔案完整名稱
    jpgname=completejpgname.split(".jpg")
    #print("File-Name：",jpgname[0])      #取得檔案名
#     if jpgname[0] != "S__122601518":
#         continue
    img = Image.open(imgpath+completejpgname) 
    img1 = ImageDraw.Draw(img)  
    width, height = img.size
    r = width/height
    #print("width:", width, "height:", height)
    _line = []
    _angle = []
    LF = open(linePath+jpgname[0]+".txt", 'r')
    for line in LF.readlines():
        line = line.strip("\n")
        line = line.strip("[")
        line = line.strip("]")
        line = line.split(",")
#         print(line)
        l = [float(s) for s in line]
        _line.append(l)
#         print("line:",l)
        _angle.append(calAngle(l))
    
    #print("_line:", _line)
    #print("_angle:", _angle)
    LF.close()
    _meanA = []
    _meanL = []
    for ai in range(len(_angle)):
#         idxA = _angle.index(a)#角度一致不可這樣用
        if _meanA == []:
            _meanA.append(_angle[ai])
            _meanL.append([ai])
        else:
            b=True
#             aB = True
#             dB = True
#             print("_meanA:", _meanA)
#             print("_meanL:", _meanL)
            for mi in range(len(_meanA)):
                #print("m v.s.a", _meanA[mi], _angle[ai])
#                 idxM= _meanA.index(m)   
#                 print("idxA v.s.idxM", ai, mi)           
                if abs(_meanA[mi]-_angle[ai]) <=angleT and b:      #same angle
                    for l in _meanL[mi]:
                        #print("la v.s. lm",_line[ai], _line[l])
                        laX1, laY1, laX2, laY2 = _line[ai]
                        lmX1, lmY1, lmX2, lmY2 = _line[l]
                        d1 = distance.euclidean((laX1, laY1), (lmX1, lmY1))
                        d2 = distance.euclidean((laX1, laY1), (lmX2, lmY2))
                        d3 = distance.euclidean((laX2, laY2), (lmX1, lmY1))
                        d4 = distance.euclidean((laX2, laY2), (lmX2, lmY2))
                        minDis = min(d1, d2, d3, d4)
#                         print("d1", d1)
#                         print("d2", d2)
#                         print("d3", d3)
#                         print("d4", d4)
                        #print("minDis", minDis)
#                         if abs(a) <=45: #dy
                            
#                         else: #dx
#                             print("dx")
#                         print("minDis:", minDis)
                        if minDis<disT:
#                             print("in")
                            b=False
                            _meanL[mi].append(ai)
                            #print("append:", ai)
                            s = 0
                            for l in _meanL[mi]:
                                s = s+_angle[l]
        #                     print("sum:", s)
        #                     print("mean:", s/len(_meanL[idxM]))
                            _meanA[mi] = s/len(_meanL[mi])
                            break
                #print("============================")
            if b :
                _meanA.append(_angle[ai])
                _meanL.append([ai])
                #print("b_append", [ai])
            #print("_meanA:", _meanA)
            #print("_meanL:", _meanL)
            #print("===============\n")

    #print("===============")            
    #print("_meanA:", _meanA)
    #print("_meanL:", _meanL)
    #print("===============")  
        
    _w = []
    _w_point = []
    for l in _meanL: #幾條線的次數(哪些線是同一條線)
#         print("l", l)
        X=[]
        Y=[]
        for idx in l:
#             print("idx:", idx, ", _line[idx]:", _line[idx])
            X.append(_line[idx][0])
            Y.append(_line[idx][1])
            X.append(_line[idx][2])
            Y.append(_line[idx][3])    
        min_point = [min(X), Y[X.index(min(X))]]
        max_point = [max(X), Y[X.index(max(X))]]
        _w_point.append([min_point, max_point])
        n = len(Y)
        x_mat = np.c_[np.ones(n), X]
        w = least_squares(Y, x_mat)
#         print(w)
        _w. append(w)
    #print("_w_point",_w_point)
    #print("_w",_w)
    #print("===============")  

#     畫線=======================
    fLine = open(intePath+jpgname[0]+".txt", 'w')
    for wi in range(len(_w)):
        w = _w[wi]
#         print("w:", w)
#         print("_w_point:", _w_point[wi])
        w_min = _w_point[wi][0]
        w_max = _w_point[wi][1]
        #print("min", w_min)
        #print("max", w_max)
#         Y = w[0]+w[1]*X
        x1 = w_min[0]
        y1 = w[0]+w[1]*x1
        x2 = w_max[0]
        y2 = w[0]+w[1]*x2
        shape = [x1, y1, x2, y2]
        shape2 = [w_min[0], w_min[1], w_max[0], w_max[1]]
        #print("shape:", shape)
        #print("shape2:", shape2)
        img1.line(shape, fill ="yellow", width=80)
#         img1.line(shape2, fill ="green", width=10)
        fLine.write(str(shape)+"\n")
    fLine.close()
        

    #print("\n============================")
    
    img.save(intePath+jpgname[0]+".jpg")
#     畫線=======================
#     break