import cv2
import os
import numpy as np


def cv_imread(filePath):
    cv_img=cv2.imdecode(np.fromfile(filePath.split('\n')[0],dtype=np.uint8),-1)
    
    # cv_img=cv2.cvtColor(cv_img,cv2.COLOR_RGB2BGR)
    return cv_img
    # 圖片路徑有中文的轉碼


# 彩色圖像全局直方圖均衡化
def hisEqulColor1(img):
	# 將RGB圖像轉換到YCrCb空間中
    ycrcb = cv2.cvtColor(img, cv2.COLOR_BGR2YCR_CB)
    # 將YCrCb圖像通道分離
    channels = cv2.split(ycrcb)
    # 對第1個通道即亮度通道進行全局直方圖均衡化並保存
    cv2.equalizeHist(channels[0],channels[0])
    # 將處理後的通道和沒有處理的兩個通道合併，命名爲ycrcb
    cv2.merge(channels,ycrcb)
    # 將YCrCb圖像轉換回RGB圖像
    cv2.cvtColor(ycrcb, cv2.COLOR_YCR_CB2BGR, img)
    return img


# 彩色圖像進行自適應直方圖均衡化，代碼同上的地方不再添加註釋
def hisEqulColor2(img):
    ycrcb = cv2.cvtColor(img, cv2.COLOR_BGR2YCR_CB)
    channels = cv2.split(ycrcb)
    
    clahe = cv2.createCLAHE(clipLimit=2.0,tileGridSize=(8,8))
    clahe.apply(channels[0],channels[0])

    cv2.merge(channels,ycrcb)
    cv2.cvtColor(ycrcb, cv2.COLOR_YCR_CB2BGR, img)
    return img


with open("/Users/joy/project/final/predict.txt", 'r') as file_:
    for line in file_:
        line=line.strip('\n') #去除圖片路徑的換行
        print(line)
        img=cv_imread(line)
        img1 = img.copy()
        img2 = img.copy()
        res1 = hisEqulColor1(img1)
        #res2 = hisEqulColor2(img2)
        # cv2.imwrite('./clahe_test/{}'.format(line.split('\n')[0].split('\\')[-1]), res)
        completejpgname=os.path.basename(line)        
        cv2.imwrite('/Users/joy/project/final/preprocess/'+completejpgname, res1)