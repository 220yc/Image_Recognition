import os

def rename_to_jpg(folder_path):
    # 確保輸入的路徑是一個資料夾
    if not os.path.isdir(folder_path):
        print("指定的路徑不是一個資料夾。")
        return
    
    # 列出資料夾中的所有檔案
    files = os.listdir(folder_path)
    
    # 遍歷所有檔案
    for file in files:
        # 取得檔案的完整路徑
        file_path = os.path.join(folder_path, file)
        # 確認該檔案是一個檔案，且是影像檔
        if os.path.isfile(file_path) and file.lower().endswith(('.jpg', '.jpeg', '.png', '.gif')):
            # 取得檔案的副檔名
            _, extension = os.path.splitext(file)
            # 如果副檔名不是.jpg，則將檔案改名為以.jpg結尾
            if extension not in ['.jpg']:
                new_file_path = os.path.join(folder_path, file.split('.')[0] + '.jpg')
                os.rename(file_path, new_file_path)
                print(f"已將檔案 {file} 改名為 {os.path.basename(new_file_path)}")

# 指定資料夾路徑
folder_path = "/Users/joy/project/IMG/"

# 執行函數
rename_to_jpg(folder_path)
