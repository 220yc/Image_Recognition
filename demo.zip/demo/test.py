import os

def get_img_path():
    """Generate a list of image file paths."""
    os.system("ls /Users/joy/project/final/test/* > /Users/joy/project/final/test.txt")

def preprocess():
    os.system("python demo/clahe_RGB_final0.py")            
    os.system("ls /Users/joy/project/final/preprocess/* > /Users/joy/project/final/preprocess.txt")
    
def ver_detect():
    """Run vertical detection on the images."""
    os.system((
        "./darknet detector test "
        "/Users/joy/darknet-master/guardrail/vec/obj.data "
        "/Users/joy/darknet-master/guardrail/vec/yolov4-obj.cfg "
        "/Users/joy/darknet-master/guardrail/vec/backup/vec.weights "
        "-thresh 0.5 -iou_thresh 0.1 -dont_show -ext_output "
        "< /Users/joy/project/final/preprocess.txt "
        "> /Users/joy/project/final/predict_result/all_vec_result.txt"
    ))
    print("Vertical detection done!")

def deck_detect():
    """Run deck detection on the images."""
    os.system((
        "./darknet detector test "
        "/Users/joy/darknet-master/guardrail/deck/obj.data "
        "/Users/joy/darknet-master/guardrail/deck/yolov4-obj.cfg "
        "/Users/joy/darknet-master/guardrail/deck/backup/deck.weights "
        "-thresh 0.1 -iou_thresh 0.2 -dont_show -ext_output "
        "< /Users/joy/project/final/preprocess.txt "
        "> /Users/joy/project/final/predict_result/all_deck_result.txt"
    ))
    print("Deck detection done!")

def get_hor():
    """Run a script to prepare for horizontal detection and generate a list of paths."""
    os.system("python demo/gethor.py")
    print("Get horizontal data done!")
    os.system("ls /Users/joy/project/final/deck/perspect/500/* > /Users/joy/project/final/hor.txt")

def hor_detect():
    """Run horizontal detection on the images."""
    os.system("ls /Users/joy/project/final/deck/perspect/500/* > /Users/joy/project/final/hor.txt")
    command = (
        "./darknet detector test "
        "/Users/joy/darknet-master/guardrail/hor/obj.data "
        "/Users/joy/darknet-master/guardrail/hor/yolov4-obj.cfg "
        "/Users/joy/darknet-master/guardrail/hor/backup/hor.weights "
        "-thresh 0.2 -iou_thresh 0.1 -dont_show -ext_output "
        "< /Users/joy/project/final/hor.txt "
        "> /Users/joy/project/final/predict_result/hor_result.txt"
    )
    os.system(command)
    print("Horizontal detection done!")

def get_final_result():
    """Run the final result aggregation script."""
    os.system("python demo/demo.py")
    print("Final result aggregation done!")

def main():
    """Main function to execute all steps."""
    get_img_path()
    ver_detect()
    deck_detect()
    get_hor()
    hor_detect()
    get_final_result()

if __name__ == "__main__":
    main()

    

